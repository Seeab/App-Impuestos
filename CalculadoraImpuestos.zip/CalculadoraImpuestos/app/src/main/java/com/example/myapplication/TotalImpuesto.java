package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.view.View;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;

public class TotalImpuesto extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_total_impuesto);

        // Obtener el valor total calculado en la clase anterior y mostrarlo en un TextView transformándolo de cadena a decimal
        double totalConImpuestos = getIntent().getDoubleExtra("totalConImpuestos", 0.0);
        double valorIngresado = getIntent().getDoubleExtra("valorIngresado", 0.0);
        double impuestos6 = getIntent().getDoubleExtra("Impuestos6", 0.0); // Corregido
        double iva19 = getIntent().getDoubleExtra("iva", 0.0); // Corregido

        TextView textViewResultado = findViewById(R.id.tv_totalConImpuestos);
        TextView textViewValorIngresado = findViewById(R.id.tv_valorIngresado);
        TextView textViewimpuestos6 = findViewById(R.id.tv_6x100to);
        TextView textViewiva = findViewById(R.id.tv_19x100to);

        textViewResultado.setText("Total con Impuestos: " + String.format("%.2f", totalConImpuestos));
        textViewValorIngresado.setText("Monto Ingresado: " + String.format("%.2f", valorIngresado));
        textViewimpuestos6.setText("Impuestos Aduana: " + String.format("%.2f", impuestos6)); // Corregido
        textViewiva.setText("Total IVA: " + String.format("%.2f", iva19)); // Corregido


        // Declarar el boton volver y asignarle la funcion
        ImageButton btn_volver = findViewById(R.id.btn_volver);
        btn_volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                volverAIngresoPedido();
            }
        });
    }
        // Funcion boton volver
    private void volverAIngresoPedido() {
        Intent intent = new Intent(TotalImpuesto.this, IngresoPedido.class);
        startActivity(intent);
    }
}
