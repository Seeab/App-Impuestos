package com.example.myapplication;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class HistorialPedidos extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private TextView tvValorSeleccionado;
    private TextView tvTotalSeleccionado;
    private Button btnEliminar;
    private long selectedItemId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historial);

        dbHelper = new DatabaseHelper(this);

        // Obtener referencias a los elementos UI
        tvValorSeleccionado = findViewById(R.id.tv_valor_seleccionado);
        tvTotalSeleccionado = findViewById(R.id.tv_total_seleccionado);
        btnEliminar = findViewById(R.id.btn_eliminar);

        // Mostrar los registros en el ListView
        mostrarRegistros();

        // Declarar el botón volver y asignarle la función
        findViewById(R.id.btn_volver).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                volverAIngresoPedido();
            }
        });

        // Agregar un OnItemClickListener al ListView para seleccionar un registro
        final ListView listView = findViewById(R.id.lv_calculos);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedItemId = id;
                mostrarDetalleRegistro(id);
            }
        });

        // Agregar un OnClickListener al botón eliminar
        btnEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedItemId != -1) {
                    eliminarRegistro(selectedItemId);
                    mostrarRegistros();
                    selectedItemId = -1; // Reiniciar la selección
                }
            }
        });
    }

    // Función para mostrar los registros en el ListView
    private void mostrarRegistros() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Realizar una consulta a la base de datos para obtener los registros
        String[] projection = {
                DatabaseHelper.COLUMN_ID,
                DatabaseHelper.COLUMN_VALOR,
                DatabaseHelper.COLUMN_TOTAL_CON_IMPUESTOS
        };

        Cursor cursor = db.query(
                DatabaseHelper.TABLE_CALCULOS,
                projection,
                null,
                null,
                null,
                null,
                null
        );

        // Crear un adaptador para mostrar los datos en el ListView
        String[] fromColumns = {
                DatabaseHelper.COLUMN_VALOR,
                DatabaseHelper.COLUMN_TOTAL_CON_IMPUESTOS
        };

        int[] toViews = {
                R.id.tv_valor,
                R.id.tv_totalConImpuestos
        };

        SimpleCursorAdapter adapter = new SimpleCursorAdapter(
                this,
                R.layout.list_item,
                cursor,
                fromColumns,
                toViews,
                0
        );

        ListView listView = findViewById(R.id.lv_calculos);
        listView.setAdapter(adapter);
    }

    // Función para mostrar el detalle de un registro seleccionado
    private void mostrarDetalleRegistro(long id) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] projection = {
                DatabaseHelper.COLUMN_VALOR,
                DatabaseHelper.COLUMN_TOTAL_CON_IMPUESTOS
        };

        String selection = DatabaseHelper.COLUMN_ID + " = ?";
        String[] selectionArgs = {String.valueOf(id)};

        Cursor cursor = db.query(
                DatabaseHelper.TABLE_CALCULOS,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        if (cursor.moveToFirst()) {
            tvValorSeleccionado.setText("Valor Seleccionado: " + cursor.getString(0));
            tvTotalSeleccionado.setText("Total con Impuestos Seleccionado: " + cursor.getString(1));
            tvValorSeleccionado.setVisibility(View.VISIBLE);
            tvTotalSeleccionado.setVisibility(View.VISIBLE);
            btnEliminar.setVisibility(View.VISIBLE);
        }
    }


    // Función para eliminar un registro de la base de datos por su ID
    private void eliminarRegistro(long id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        String whereClause = DatabaseHelper.COLUMN_ID + " = ?";
        String[] whereArgs = {String.valueOf(id)};
        db.delete(DatabaseHelper.TABLE_CALCULOS, whereClause, whereArgs);
        db.close();
    }

    // Función botón volver
    private void volverAIngresoPedido() {
        Intent intent = new Intent(HistorialPedidos.this, IngresoPedido.class);
        startActivity(intent);
    }
}
