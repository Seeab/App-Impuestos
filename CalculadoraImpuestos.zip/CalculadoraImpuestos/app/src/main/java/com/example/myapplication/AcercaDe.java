package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class AcercaDe extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acercade);{
    }
        // Declarar el boton volver y asignarle la funcion
        ImageButton btn_volver = findViewById(R.id.btn_volver);
        btn_volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                volverAIngresoPedido();
            }
        });
    }
        // Funcion boton volver
        private void volverAIngresoPedido() {
        Intent intent = new Intent(AcercaDe.this, IngresoPedido.class);
        startActivity(intent);
        }
}