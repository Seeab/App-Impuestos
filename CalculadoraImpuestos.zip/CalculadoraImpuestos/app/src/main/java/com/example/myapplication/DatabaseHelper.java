package com.example.myapplication;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "CalculosImpuestos.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_CALCULOS = "calculos";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_VALOR = "valor";
    public static final String COLUMN_TOTAL_CON_IMPUESTOS = "total_con_impuestos";

    private static final String DATABASE_CREATE = "create table "
            + TABLE_CALCULOS + "(" + COLUMN_ID
            + " integer primary key autoincrement, " + COLUMN_VALOR
            + " real not null, " + COLUMN_TOTAL_CON_IMPUESTOS
            + " real not null);";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Aca se crea por primera vez la bd
    @Override
    public void onCreate(SQLiteDatabase database) {
        database.execSQL(DATABASE_CREATE);
    }

    // y esto es el metodo para actualizar los registros
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CALCULOS);
        onCreate(db);
    }
}