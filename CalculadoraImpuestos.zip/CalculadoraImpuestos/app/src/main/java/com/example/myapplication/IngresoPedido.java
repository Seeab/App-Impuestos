package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class IngresoPedido extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText tv_totalpedido = findViewById(R.id.tv_totalpedido);
        Button btn_Calcular = findViewById(R.id.btn_Calcular);

        btn_Calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calcularImpuestos(tv_totalpedido);
            }
        });

        // Declarar el boton acerca de y asignarle la funcion
        ImageButton btn_acercade = findViewById(R.id.btn_acercade);
        btn_acercade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { acercaDe(); }
        });

        // Declarar el boton historial asignarle la funcion
        Button btn_historial = findViewById(R.id.btn_historial);
        btn_historial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { historialPedidos(); }
        });
    }

    // Funcion de calcular
    private void calcularImpuestos(EditText editText) {
        String valorIngresado = editText.getText().toString();

        if (!valorIngresado.isEmpty()) {
            double valor = Double.parseDouble(valorIngresado);

            if (valor > 36000) {
                double impuestos6 = valor * 0.06;
                double iva19 = (valor + impuestos6) * 0.19;
                double totalConImpuestos = valor + impuestos6 + iva19;

                DatabaseHelper dbHelper = new DatabaseHelper(this);
                SQLiteDatabase db = dbHelper.getWritableDatabase();

                ContentValues values = new ContentValues();
                values.put(DatabaseHelper.COLUMN_VALOR, valor);
                values.put(DatabaseHelper.COLUMN_TOTAL_CON_IMPUESTOS, totalConImpuestos);

                db.insert(DatabaseHelper.TABLE_CALCULOS, null, values);
                db.close();

                // Pasar al otro activity con el resultado
                Intent intent = new Intent(IngresoPedido.this, TotalImpuesto.class);
                intent.putExtra("valorIngresado", valor);
                intent.putExtra("Impuestos6", impuestos6);
                intent.putExtra("iva", iva19);
                intent.putExtra("totalConImpuestos", totalConImpuestos);
                startActivity(intent);
            } else {
                // Notificacion de monto insuficiente para impuestos
                Toast.makeText(IngresoPedido.this, "No se aplican impuestos para montos menores o iguales a 36,000", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(IngresoPedido.this, "Ingrese un valor válido", Toast.LENGTH_SHORT).show();
        }
    }

    // Funcion Boton acerca de
    private void acercaDe(){
        Intent intent = new Intent(IngresoPedido.this, AcercaDe.class);
        startActivity(intent);     }

    // Funcion Boton Historial (Activity implementado pero no esta desarrollado)
    private void historialPedidos(){
        Intent intent = new Intent(IngresoPedido.this, HistorialPedidos.class);
        startActivity(intent);     }

}
